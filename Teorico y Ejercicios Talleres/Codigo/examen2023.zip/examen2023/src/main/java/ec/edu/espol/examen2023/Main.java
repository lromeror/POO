package ec.edu.espol.examen2023;
import modelo.*;
import java.util.ArrayList;
class Main {
  public static void main(String[] args) {
    MyPhotos app = new MyPhotos();
    ArrayList<Archivo> seleccion = app.armarCarrusel(5);
    app.mostrarCarrusel(seleccion);
  }
}