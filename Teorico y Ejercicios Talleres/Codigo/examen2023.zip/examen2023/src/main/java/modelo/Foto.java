/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author eduardo
 */
public class Foto extends Archivo{
    private TipoFormato formato;

    public Foto(String nombre, String fecha, double tamanio,TipoFormato formato) {
        super(nombre, fecha, tamanio);
        this.formato = formato;
    }
    @Override
    public String toString()
    {
        return "Foto "+super.toString()+" - Formato:"+this.formato;
    }
    
    public void visualizar()
    {
        System.out.println("Mostrando Foto "+this.toString());
    }
}
