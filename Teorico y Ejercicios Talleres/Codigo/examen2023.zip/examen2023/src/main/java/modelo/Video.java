/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author eduardo
 */
public class Video extends Archivo{
    private int duracion;

    public Video(String nombre, String fecha, double tamanio, int duracion) {
        super(nombre, fecha, tamanio);
        this.duracion = duracion;
    }

    public int getDuracion() {
        return duracion;
    }
    
    @Override
    public String toString()
    {
        return "Video "+super.toString()+" - Duracion:"+this.duracion;
    }
    
    public void reproducir(int t)
    {
        System.out.println("Reproduciendo "+this.toString()+" por "+t+" segundos");
    }
}
