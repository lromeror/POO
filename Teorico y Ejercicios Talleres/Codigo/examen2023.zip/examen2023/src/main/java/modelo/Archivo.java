/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author eduardo
 */
public abstract class Archivo {
    private String nombre;
    private String fecha;
    private double tamanio;

    public Archivo(String nombre, String fecha, double tamanio) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.tamanio = tamanio;
    }

    public String getFecha() {
        return fecha;
    }
    
    @Override
    public String toString()
    {
        return "Nombre :"+this.nombre+" - Tamaño:"+this.tamanio;
    }
}
