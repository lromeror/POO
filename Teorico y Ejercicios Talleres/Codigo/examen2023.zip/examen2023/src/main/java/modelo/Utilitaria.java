/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author eduardo
 */
public class Utilitaria {
    public static ArrayList<Archivo> filtrarArchivos(ArrayList<Archivo> archivos, int mes)
    {
        ArrayList<Archivo> res = new ArrayList<>();
        for(Archivo a : archivos)
        {
            String fecha = a.getFecha();//dd-mm-YYYY
            String[] tokens = fecha.split("-");
            int m = Integer.parseInt(tokens[1]);
            if(mes == m) 
                res.add(a);
        }
        return res;
    }
}
