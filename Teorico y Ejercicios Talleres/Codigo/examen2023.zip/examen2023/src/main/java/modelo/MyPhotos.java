package modelo;
import java.util.ArrayList;
import java.util.Arrays;

public class MyPhotos{
  ArrayList<Archivo> archivos;
  public MyPhotos(){
    //llama al método que carga los archivos
     cargarArchivos();
  }

  public void cargarArchivos(){
    Archivo[] arreglo = {
    new Foto("paseo1","2022-05-20",25,TipoFormato.PNG),
    new Foto("paseo2","2022-05-20",25,TipoFormato.JPEG),
    new Foto("paseo3","2022-05-20",25,TipoFormato.PNG),
    new Foto("paseo4","2022-05-20",25,TipoFormato.TIFF),
    new Foto("paseo5","2022-05-20",25,TipoFormato.JPEG),
    new Video("paisaje","2022-05-20",100,33),
    new Foto("paseo7","2022-05-20",25,TipoFormato.JPEG),
    new Video("comida1","2022-05-20",110,40),
    new Video("comida2","2022-05-20",110,50),
    new Video("comida3","2022-05-20",110,40),
    new Video("comida4","2022-05-20",110,50),
    new Video("comida5","2022-05-20",110,40),
    new Video("comida6","2022-05-20",110,5),
    new Foto("paseo6","2022-05-20",25,TipoFormato.PNG),  
    new Foto("trabajo1","2022-06-12",25,TipoFormato.PNG),
    new Foto("trabajo2","2022-06-12",25,TipoFormato.JPEG),
    new Foto("gato","2023-05-12",25,TipoFormato.TIFF),
    new Video("reunion","2023-05-12",25,10)
    };
    archivos = new ArrayList<>(Arrays.asList(arreglo));

  }
  
  public ArrayList<Archivo> armarCarrusel(int mes)
  {
      ArrayList<Archivo> res = new ArrayList<>();
      ArrayList<Archivo> filtrados = Utilitaria.filtrarArchivos(archivos, mes);
      int duracion_total = 0;
      int index = 0;
      int duracion = 0;
      do
      {
          Archivo a = filtrados.get(index);
          if(a instanceof Video)
          {
              Video v = (Video)a;
              if(v.getDuracion()>6)
                  duracion=6;
              else
                  duracion=v.getDuracion();
          }
          else
          {
              duracion = 2;
          }
          if(duracion_total + duracion < 60)
              res.add(a);
          duracion_total+=duracion;
          index++;
          
      }while(index<filtrados.size() && duracion_total < 60);
      return res;
  }
  //IMPLEMENTAR armarCarrusel


  //IMPLEMENTAR mostrarCarrusel
  public static void mostrarCarrusel(ArrayList<Archivo> archivos)
  {
    int index = 1;
    for(Archivo a : archivos)
    {
        System.out.print(index+". ");
        if(a instanceof Video)
        {
            Video v = (Video)a;
            if(v.getDuracion()>6)
                v.reproducir(6);
            else
                v.reproducir(v.getDuracion());
        }
        else
        {
            Foto f = (Foto)a;
            f.visualizar();
        }
        index++;
    }
  }
}