/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.List;

/**
 *
 * @author rociomera
 */
public class Rutina {
    private String nombre;
    private List<Ejercicio> ejercicios;
    
    public Rutina(String nombre, List<Ejercicio> ejercicios){
        this.nombre = nombre;
        this.ejercicios = ejercicios;
    }
    
    public static List<Rutina> cargarListaRutinas(String nombreArchivo){
        return null;
    }
}
