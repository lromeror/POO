package com.pooespol.modelo;

import com.pooespol.causasdonacionestareav2.App;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Verónica
 */
public class Donacion {

    private Causa causa;
    private String donador;
    private double monto;

    public Donacion(Causa causa, String donador, double monto) {
        this.causa = causa;
        this.donador = donador;
        this.monto = monto;
    }

    public Causa getCausa() {
        return causa;
    }

    public void setCausa(Causa causa) {
        this.causa = causa;
    }

    public String getDonador() {
        return donador;
    }

    public void setDonador(String donador) {
        this.donador = donador;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public static ArrayList<Donacion> leerDonaciones(Causa c) {
      return null;
    }

    public static void escribirDonacion(String nombreCausa, String donador, double monto)  {
      
    }
}
