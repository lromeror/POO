package com.pooespol.causasdonacionestareav2;

import com.pooespol.modelo.Causa;
import java.io.FileInputStream;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import static javafx.application.Application.launch;

/**
 * JavaFX App
 */
public class App extends Application {

   private static Scene scene;
    public static String pathFiles="src/main/resources/files/";
    public static String pathImg="src/main/resources/images/";
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxmLoader=new FXMLLoader(App.class.getResource("VentanaDonaciones.fxml"));
        
        Parent root=fxmLoader.load();
        scene=new Scene(root,640,600);
        stage.setScene(scene);
        stage.show();
        
        
        
    }
    
    public static void main(String[] args) {
        launch();
        

        
    }
    

}