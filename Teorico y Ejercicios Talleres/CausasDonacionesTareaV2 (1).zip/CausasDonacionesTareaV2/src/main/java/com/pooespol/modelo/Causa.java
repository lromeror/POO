/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pooespol.modelo;

import com.pooespol.causasdonacionestareav2.App;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Verónica
 */
public class Causa implements Serializable {

    private String nombre;
    private String imagen;
    private static final long serialVersionUID=329843394474334783L;
    public Causa(String n, String imagen) {
        this.nombre = n;
        this.imagen = imagen;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public static ArrayList<Causa> leerCausas() {
       return null;
    }

    public double calcularTotal() {
       return 0;
    }

    

}
