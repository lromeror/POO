module com.pooespol.causasdonacionestareav2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.pooespol.causasdonacionestareav2 to javafx.fxml;
    exports com.pooespol.causasdonacionestareav2;
}
