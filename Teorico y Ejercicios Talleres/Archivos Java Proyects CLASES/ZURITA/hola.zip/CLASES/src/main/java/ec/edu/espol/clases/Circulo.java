/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.clases;

/**
 *
 * @author CltControl
 */
public class Circulo extends  Figura{
    private double radio;

//    public Circulo(double radio) {
//        
//        super(0);            // Solo cuando tengo herencia debo hacer esto
//        this.radio = radio;
//    }

// Cuando esta definido el default en la clase madre, solo ahi se puede obviar de poner super()
    public Circulo(double radio){
        
        this(0,0,radio);
    }
    public Circulo(int x , int y, double radio) {
        
        super(x,y);
        this.radio = radio;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }
     
    @Override
    public String toString(){
        return "(x:"+super.x+", y: "+super.y+", radio: "+this.radio+")";
    }
    
//    public String toString(){
//        return this.getX()+"x^2 + "+this.getY()+"y^2"+" = "+this.radio;
//    }
    
    public double Perimtro()
    {
        return 2*Math.PI*this.radio;
    }
}
