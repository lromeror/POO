/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espol.clases;

/**
 *
 * @author CltControl
 */
public class CLASES {

    public static void main(String[] args) {
        
        Circulo c1 = new Circulo(2.5);
        Circulo c2 = new Circulo(2.5);
        System.out.println(c1.getX());
        System.out.println(c1);
        Circulo c3 = new Circulo(4,4,16);
        System.out.println(c3);
        System.out.println(c2.perimetro());
        System.out.println(c3.perimetro());
        Figura f = new Circulo(2.5);
        System.out.println(f.perimetro());
    }
}
