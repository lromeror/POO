/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espol.clases_espol;

import java.util.ArrayList;
import ec.edu.espol.clases_espol.Fraccion;

/**
 *
 * @author CltControl
 */
public class Clases_espol {

    public static void main(String[] args) {
        Fraccion f1 = new Fraccion(3,4);
        Fraccion f3 = new Fraccion(5,7);
        ArrayList<Fraccion> fracciones = new ArrayList<>();
        fracciones.add(f1);
        fracciones.add(f3);
        Fraccion.writerSer("Lista_fracciones.doc", fracciones);
        ArrayList<Fraccion> fracciones2 = Fraccion.readSer("Lista_fracciones.doc");
       for (Fraccion f : fracciones2){
            System.out.println(f);
        }
        //f1.savefer("fraccion.ser");
    }
}

