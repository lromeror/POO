/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.clases_espol;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author CltControl
 */
public class Fraccion implements Serializable{ 
// Ya con esto nos permite escribir en bytes
        
    private int numerador ; 
    private int denominador;
    private transient String extra; /*para decir que este atributo no se escriba y cuando se lea va a pasar con su valor default*/
    private static final long serialVersionUID = 8799656478674716639L; // para no estar serializando o deserializando 
 
    public Fraccion(int numerador, int denominador) {
        this.numerador = numerador;
        this.denominador = denominador;
    }

    public int getNumerador() {
        return numerador;
    }

    public void setNumerador(int numerador) {
        this.numerador = numerador;
    }

    public int getDenominador() {
        return denominador;
    }

    public void setDenominador(int denominador) {
        this.denominador = denominador;
    }
    
    public String toString()
    {
        return this.numerador+"/"+this.denominador;
    }
    public void savefer(String nombre)
    {
        //estas clase si es AutoCloseable por lo tanto puedo hacer un try con recursos
        try(ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(nombre));)  
        {
            out.writeObject(this);  //Aquí mandamos el this porque es un objeto
          
        }
        catch(IOException e)
        {
            
        }
    } 
    
    public static void writerSer(String nombre, ArrayList<Fraccion> fracciones)
    {
        try(ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(nombre));)  
        {
            out.writeObject(fracciones);  //Aquí mandamos el this porque es un objeto
          
        }
        catch(IOException e)
        {
            
        }
    }
    public static ArrayList<Fraccion> readSer(String nombre)
    {
        ArrayList<Fraccion> fracciones = new ArrayList<>();
        try(ObjectInputStream in = new ObjectInputStream(new FileInputStream(nombre));)  
        {
            fracciones = (ArrayList<Fraccion>)in.readObject();
          
        }
        catch(IOException e )
        {
            
        }
        catch(ClassNotFoundException c )
        {
                
        }
        return fracciones;
        
    }
}
