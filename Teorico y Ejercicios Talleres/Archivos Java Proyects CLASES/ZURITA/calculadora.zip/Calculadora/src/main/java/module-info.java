module ec.edu.espol.calculadora {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens ec.edu.espol.calculadora to javafx.fxml;
    exports ec.edu.espol.calculadora;
}
