/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package ec.edu.espol.calculadora;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author CltControl
 */
public class CalculadoraController implements Initializable {

    @FXML
    private TextField f1num;
    @FXML
    private TextField f1den;
    @FXML
    private TextField f2num;
    @FXML
    private TextField f2den;
    @FXML
    private Button sumar;
    @FXML
    private Button limpiar;
    @FXML
    private TextField result;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void sumar(MouseEvent event) {
//        Alert a = new Alert(Alert.AlertType.ERROR,"zzzzzzzzzzzz");
//        a.show();
        try{
          int numf1 = Integer.parseInt(f1num.getText());
          int numf2 = Integer.parseInt(f2num.getText());
          int denf1 = Integer.parseInt(f1den.getText());
          int denf2 = Integer.parseInt(f2den.getText());
          Fraccion f1 = new Fraccion(numf1,denf1);
          Fraccion f2 = new Fraccion(numf2,denf2);
          Fraccion resulta = f1.sumar(f2);
          Alert a = new Alert(Alert.AlertType.INFORMATION,"Valores Invalidados");
          a.show();
          result.setText(resulta.toString());
        }
        catch(NumberFormatException e){      
            Alert a = new Alert(Alert.AlertType.ERROR,"Valores Invalidados");
            a.show();           
        }
        catch(DenominadorException de){
            Alert a = new Alert(Alert.AlertType.ERROR,de.getMessage());
            a.show();            
        }
        
    }

    @FXML
    private void limpiar(MouseEvent event) {
        limpiarinfo();
    }
    private void limpiarinfo(){
        f1num.setText("");
        f2num.setText("");
        f1den.setText("");
        f2den.setText("");
        result.setText("");
    }
    
}
