
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.examendesarrollo;

/**
 *
 * @author CltControl
 */
public class Foto extends Archivo {
    private TipoFormato formato;

    public Foto(String nombre, String fecha, double tamano, TipoFormato ft) {
        super(nombre, fecha, tamano);
        this.formato=ft;
    }
    
    @Override
    public String toString(){
        return "Foto"+super.toString()+"- Formato: <"+formato+">";
    }
    
    public void visualizar(){
        String mensaje="Mostrando "+toString();
        System.out.println(mensaje);
    }
    
    
}
