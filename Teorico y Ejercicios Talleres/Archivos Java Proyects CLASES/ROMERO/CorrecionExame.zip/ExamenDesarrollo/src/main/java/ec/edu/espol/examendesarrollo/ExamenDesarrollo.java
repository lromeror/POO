/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espol.examendesarrollo;

import java.util.ArrayList;

/**
 *
 * @author CltControl
 */
public class ExamenDesarrollo {

    public static void main(String[] args) {
       MyPhotos app = new MyPhotos();
        ArrayList<Archivo> seleccion = app.armarCarrusel(5);
        app.mostrarCarrusel(seleccion);
    }
}
