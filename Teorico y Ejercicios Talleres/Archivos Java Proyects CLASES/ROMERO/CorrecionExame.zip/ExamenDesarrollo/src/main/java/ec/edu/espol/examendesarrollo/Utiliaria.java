/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.examendesarrollo;

import java.util.ArrayList;

/**
 *
 * @author CltControl
 */
public class Utiliaria {
      
    
    public static ArrayList<Archivo> filtrarArchivos(ArrayList<Archivo> archivos,int mes){
        ArrayList<Archivo> fi=new ArrayList();
        for(Archivo a:archivos){
            String fecha=a.getFecha();
            String [] fechasepa=fecha.split("-");
            int mesarchivo= Integer.parseInt(fechasepa[1]);
            if (mes==mesarchivo) {
                fi.add(a);
            }
        }
        return fi ;
    }
    
}
