/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.examendesarrollo;

/**
 *
 * @author CltControl
 */
public abstract class Archivo {
    private String nombre;
    private String fecha;
    private double tamano;
    private MyPhotos foto;

    public Archivo(String nombre, String fecha, double tamano) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.tamano = tamano;
    }

    public String getFecha() {
        return fecha;
    }
    
    public String toString(){
        return "<Nombre>" +nombre+" - Tamaño: <"+tamano+">";
    }
    
}
