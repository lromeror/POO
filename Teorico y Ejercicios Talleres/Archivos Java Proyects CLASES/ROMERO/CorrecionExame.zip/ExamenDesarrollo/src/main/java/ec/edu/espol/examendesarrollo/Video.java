/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.examendesarrollo;

/**
 *
 * @author CltControl
 */
public class Video extends Archivo {
    private int duracion;

    public Video(String nombre, String fecha, double tamano, int d) {
        super(nombre, fecha, tamano);
        this.duracion=d;
    }

    public int getDuracion() {
        return duracion;
    }
    
    @Override
    public String toString(){
        return super.toString()+"- Duracion :<"+duracion+">";
    }
    
    public void reproducir(int t){
        
        String mensaje="Reproduciendo Video"+toString() +" por /"+t+"/ segundos";
        System.out.println(mensaje);
    }
    
}
