/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.classes;

import java.util.ArrayList;

/**
 *
 * @author CltControl
 */
public class Pokedex {

    private ArrayList<Pokemon> pokemones;

    public Pokedex() {
        this.pokemones = new ArrayList<>();
    }

    public void addPokemon(Pokemon poke) {
        pokemones.add(poke);
    }

    public ArrayList<Pokemon> filtrarPorTipo(String tipo) {
        
        ArrayList<Pokemon> listPokemon = new ArrayList<>();
        
        for (Pokemon x : this.pokemones) {
            if (x.getTipo().equals(tipo)) {//Compara un string y un string
                listPokemon.add(x);
            }
        }

        return listPokemon;
    }

}
