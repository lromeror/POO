/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espol.taller1_lr;

import ec.edu.espol.classes.Pokedex;
import ec.edu.espol.classes.Pokemon;
import java.util.Scanner;

/**
 *
 * @author CltControl
 */
public class Taller1_LR {

    public static void main(String[] args) {
       /*
        a.	Instanciar un objeto Scanner
b.	Instanciar un objeto Pokedex
c.	Pedir 5 pokemones por teclado y agregarlos al Pokedex
d.	Pedir un tipo de pokemon por teclado
e.	Filtrar el pokedex por el tipo recibido por teclado e imprimir la lista filtrada.
f.	Extraer los dos primeros pokemones de la lista filtrada con el comportamiento get de la lista y simular el ataque del primer pokemon con el segundo.
g.	Mostrar la información de estos dos pokemones por pantalla.

        */
       Pokedex listPoke=new Pokedex();
        
        
       Scanner input=new Scanner(System.in);
       Pokemon p1= Pokemon.metodoScanner(input);
       listPoke.addPokemon(p1);
        
        
       Pokemon p2= Pokemon.metodoScanner(input);
     listPoke.addPokemon(p2);
        
       
       Pokemon p3= Pokemon.metodoScanner(input);
      listPoke.addPokemon(p3);
        
       Pokemon p4= Pokemon.metodoScanner(input);
       listPoke.addPokemon(p4);
     
        
       Pokemon p5= Pokemon.metodoScanner(input);
       
        
        listPoke.addPokemon(p5);
       
       
      
        
       
        
       
    }
}
