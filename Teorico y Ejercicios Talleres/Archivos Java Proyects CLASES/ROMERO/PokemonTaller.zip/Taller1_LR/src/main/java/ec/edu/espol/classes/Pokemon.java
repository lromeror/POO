/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.classes;

import java.util.Scanner;

/**
 *
 * @author CltControl
 */
public class Pokemon {
    private String nombre;
    private String tipo;
    private int ataque;
    private int defensa;
    private int resistencia;

    public Pokemon(String nombre, String tipo, int ataque, int defensa, int resistencia) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.ataque = ataque;
        this.defensa = defensa;
        this.resistencia = resistencia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public int getDefensa() {
        return defensa;
    }

    public void setDefensa(int defensa) {
        this.defensa = defensa;
    }

    public int getResistencia() {
        return resistencia;
    }

    public void setResistencia(int resistencia) {
        this.resistencia = resistencia;
    }
    
    public void atacar(Pokemon poke){
        if(this.defensa>poke.getDefensa()){
            poke.resistencia-=this.ataque;
        }
    }
    
    @Override
    public String toString(){
        
        return "<Pokemon>->nombre: "+this.nombre+", tipo: "+this.tipo+", ataque: "+this.ataque+", Defensa: "+this.defensa+", resistencia: "+this.resistencia;  
    }
    
    @Override
    public boolean equals(Object ob) {
        if (ob == null) {
            return false;
        }

        if (this == ob) {
            return false;
        }

        if (this.getClass() != ob.getClass()) {
            return false;
        }
        
        Pokemon otro =(Pokemon) ob;
        
        return (this.nombre==otro.getNombre() && this.tipo==otro.getTipo());
    }
    
    public static Pokemon metodoScanner(Scanner input){
        System.out.println("Ingrese el nombre del Pokemmon");
        String nombre=input.nextLine();
        System.out.println("Ingrese el tipo del Pokemmon");
        String tipo=input.nextLine();
       
       
        System.out.println("Ingrese el resistencia del Pokemmon");
        int resistencia=input.nextInt();
        int defensa;
        
        do{
            System.out.println("Ingrese el defensa del Pokemmon");
            defensa=input.nextInt();
            
        }while(defensa<0);
        
        int ataque;
        do{
            System.out.println("Ingrese el defensa del Pokemmon");
            ataque=input.nextInt();
            
        }while(ataque<0);
        
        Pokemon pokemonUser=new Pokemon(nombre,tipo,ataque,defensa,resistencia);
        input.nextLine();
        return pokemonUser;
    }
    

}
