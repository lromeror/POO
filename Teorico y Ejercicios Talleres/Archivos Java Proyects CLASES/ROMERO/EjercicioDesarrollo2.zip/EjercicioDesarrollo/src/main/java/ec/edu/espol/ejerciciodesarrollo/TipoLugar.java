/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package ec.edu.espol.ejerciciodesarrollo;

/**
 *
 * @author CltControl
 */
//Clase enumeracion
//Asignar un valor actergorico
public enum TipoLugar {//No hay que poner tipo de dato solamente las variables como atributos
    //Podemos decir que son como estaticas
    MUSEO,RESTAURANTE,PARQUE,HOTEL;   
}



