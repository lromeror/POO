/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espol.juegodominotarea;

/**
 *
 * @author Jonanyu 11.1
 */
public class JuegoDominoTarea {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
